#include <stdio.h>
#include "fact.h"

void foo()
{
}

int main()
{
	int n = 5;
	int res = fact(n);
	printf("result : %d\n", res);
}
