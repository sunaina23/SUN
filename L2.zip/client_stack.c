#include <stdio.h>
#include "stack.h"

int main()
{
	stack_t mystack;
	int n = 5;
	init(&mystack);
	for(int i = 0; i < n; ++i)
	{
		push(&mystack, i * i * i);
	}
	while(! empty(&mystack) )
	{
		printf("%d\n", pop(&mystack));
	}
}
