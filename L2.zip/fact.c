#include "fact.h"
#if 0
void foo()
{
}
#endif
int fact(int n)
{
#if 0
	int res = 1;
	while(n)
	{
		res *= n--;	
	}
	return res;
#endif
	if(n == 0)
	{
		return 1;
	}
	else
	{
		return n * fact(n - 1);
	}
}
