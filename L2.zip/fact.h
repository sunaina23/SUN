int fact(int);
