#include <stdio.h>
#include <stdlib.h>
#include "stack.h"
void init(stack_t *ptr_stack)
{
	ptr_stack->sp = 0; // NULL
}
void push(stack_t *ptr_stack, int elem)
{
	node_t *temp;
	temp = (node_t*)malloc(sizeof(node_t));
	temp->key = elem;
	temp->link = ptr_stack->sp;
	ptr_stack->sp = temp;
}

int pop(stack_t *ptr_stack)
{
	node_t *temp;
	int res;
	temp = ptr_stack->sp;
	res = temp->key;
	ptr_stack->sp = temp->link;
	free(temp);
	return res;
}

int empty(const stack_t *ptr_stack)
{
	return ptr_stack->sp == 0;
}
