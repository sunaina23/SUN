#ifndef STACK_H
#define STACK_H
/*
	Stack: is a data structure
	LIFO 
	insertion and deletion at one end
	operations:
		create a stack
		
		push - on a stack a component(as of now int)
		pop - on a stack; return the component
		top - on a stack; check the last element
		empty - of a stack
		full - of a stack
*/
// implement based on linked list
// linked list implementation of the stack

struct node
{
	int key;
	struct node *link;
};
typedef struct node node_t;

struct stack
{
	node_t* sp;
};
typedef struct stack stack_t;
void init(stack_t *ptr_stack);
void push(stack_t *ptr_stack, int elem);
int pop(stack_t *ptr_stack);
int empty(const stack_t *ptr_stack);

#endif












