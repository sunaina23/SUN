#include <stdio.h>
#include <time.h>
#include <unistd.h>

int main()
{
	struct timespec start;
	struct timespec end;
	clock_gettime( CLOCK_REALTIME , &start);
	sleep(10);
	clock_gettime(  CLOCK_REALTIME, &end);
	printf("%ld : %ld - %ld : %ld\n",
		end.tv_sec, end.tv_nsec,
		start.tv_sec, start.tv_nsec);
}
	 

